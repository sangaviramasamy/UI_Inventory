(function(){ try {var elementStyle = document.createElement('style'); elementStyle.appendChild(document.createTextNode("html:not([dark]) button[data-v-498b5b0a]{border:none;background:none;cursor:pointer;font-family:Blibli,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif}html:not([dark]) input[type=submit][data-v-498b5b0a]::-moz-focus-inner,html:not([dark]) input[type=button][data-v-498b5b0a]::-moz-focus-inner{border:0px}html:not([dark]) button[data-v-498b5b0a]:focus,html:not([dark]) input[type=submit][data-v-498b5b0a]:focus,html:not([dark]) input[type=button][data-v-498b5b0a]:focus,html:not([dark]) input[type=reset][data-v-498b5b0a]:focus,html:not([dark]) a[data-v-498b5b0a]{outline:none}html:not([dark]) .blu-button[data-v-498b5b0a]{--blu-button-border-width: 1px;--blu-button-border-radius: 64px;--blu-button-color-text: #ffffff;--blu-button-color-icon: #ffffff;--blu-button-opacity: $blu-button-opacity;--blu-button-size-height: 48px;--blu-button-icon-size: 24px;--blu-button-spacing-padding: 0 32px;--blu-button-spacing-gap: 8px;--blu-button-text: 600 16px/20px Blibli, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;padding:var(--blu-button-spacing-padding);height:var(--blu-button-size-height);border-radius:var(--blu-button-border-radius);transition:transform .3s .08s,all .3s;color:var(--blu-button-color-text);background-color:var(--blu-button-color-background);font:var(--blu-button-text);box-shadow:0 0 0 var(--blu-button-border-width) var(--blu-button-color-border);display:inline-flex;justify-content:center;align-items:center;white-space:nowrap}html:not([dark]) .blu-button[data-v-498b5b0a]:active:hover:not(.b-disabled),html:not([dark]) .blu-button:active.b-hover[data-v-498b5b0a]:not(.b-disabled){transform:scale(.875)}html:not([dark]) .blu-button[data-v-498b5b0a]:focus-visible{outline:none}html:not([dark]) .blu-button[data-v-498b5b0a]:focus-visible:not(.b-disabled){box-shadow:0 0 0 2px #19222a}html:not([dark]) .blu-button__icon[data-v-498b5b0a]{display:flex;color:var(--blu-button-color-icon)}html:not([dark]) .blu-button__icon[data-v-498b5b0a] svg{width:var(--blu-button-icon-size);height:var(--blu-button-icon-size)}html:not([dark]) .blu-button.b-has-icon:not(.b-has-icon-only) .blu-button__icon[data-v-498b5b0a]{margin-right:var(--blu-button-spacing-gap)}html:not([dark]) .blu-button.b-has-icon-only[data-v-498b5b0a]{--blu-button-spacing-padding: 0 12px}html:not([dark]) .blu-button.b-loading[data-v-498b5b0a] .blu-loader-wrapper svg{display:flex;width:18px;height:18px}html:not([dark]) .blu-button.b-disabled[data-v-498b5b0a]{cursor:not-allowed}html:not([dark]) .blu-button.b-disabled[data-v-498b5b0a]:active{pointer-events:none}html:not([dark]) .blu-button.b-full-width[data-v-498b5b0a]{width:100%}html:not([dark]) .blu-button.b-primary.b-common[data-v-498b5b0a]{--blu-button-color-background: #0072ff}html:not([dark]) .blu-button.b-primary.b-common.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-common[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-common[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-common[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #1d8fff;--blu-button-color-border: transparent}html:not([dark]) .blu-button.b-primary.b-danger[data-v-498b5b0a]{--blu-button-color-background: #e93c3c}html:not([dark]) .blu-button.b-primary.b-danger.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-danger[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-danger[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-danger[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #ff4646;--blu-button-color-border: transparent}html:not([dark]) .blu-button.b-primary.b-inverted[data-v-498b5b0a]{--blu-button-color-background: #ffffff;--blu-button-color-text: #006dea;--blu-button-color-icon: #0072ff}html:not([dark]) .blu-button.b-primary.b-inverted.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-inverted[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-inverted[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-primary.b-inverted[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #f9f9fa;--blu-button-color-border: transparent}html:not([dark]) .blu-button.b-primary.b-disabled[data-v-498b5b0a]{--blu-button-color-background: #e1e3e4;--blu-button-color-text: rgba(25, 34, 42, .2);--blu-button-color-icon: rgba(25, 34, 42, .2)}html:not([dark]) .blu-button.b-primary.b-disabled[data-v-498b5b0a]:not(.b-inverted){--blu-button-color-background: #e1e3e4;--blu-button-color-text: rgba(25, 34, 42, .2);--blu-button-color-icon: rgba(25, 34, 42, .2)}html:not([dark]) .blu-button.b-small[data-v-498b5b0a]{--blu-button-border-radius: 64px;--blu-button-size-height: 36px;--blu-button-spacing-padding: 0 16px;--blu-button-text: 600 14px/18px Blibli, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;--blu-button-icon-size: 18px;--blu-button-spacing-gap: 4px}html:not([dark]) .blu-button.b-small.b-has-icon-only[data-v-498b5b0a]{--blu-button-spacing-padding: 0 9px}html:not([dark]) .blu-button[data-v-498b5b0a]{width:var(--blu-button-custom-width)}html:not([dark]) .blu-button.b-secondary[data-v-498b5b0a]{--blu-button-color-background: #ffffff}html:not([dark]) .blu-button.b-secondary.b-common[data-v-498b5b0a]{--blu-button-color-border: #1d8fff;--blu-button-color-text: #006dea;--blu-button-color-icon: #0072ff}html:not([dark]) .blu-button.b-secondary.b-common.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-common[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-common[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-common[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #f3f9ff;--blu-button-color-border: #0072ff}html:not([dark]) .blu-button.b-secondary.b-danger[data-v-498b5b0a]{--blu-button-color-border: #ff4646;--blu-button-color-text: #d33534;--blu-button-color-icon: #e93c3c}html:not([dark]) .blu-button.b-secondary.b-danger.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-danger[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-danger[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-danger[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #fff5f5;--blu-button-color-border: #e93c3c}html:not([dark]) .blu-button.b-secondary.b-inverted[data-v-498b5b0a]{--blu-button-color-background: rgba(25, 34, 42, .2);--blu-button-color-border: #ffffff;--blu-button-color-text: #ffffff;--blu-button-color-icon: #ffffff}html:not([dark]) .blu-button.b-secondary.b-inverted.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-inverted[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-inverted[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-secondary.b-inverted[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: rgba(255, 255, 255, .4);--blu-button-color-border: #ffffff}html:not([dark]) .blu-button.b-secondary.b-disabled[data-v-498b5b0a]{--blu-button-color-background: #e1e3e4;--blu-button-color-border: #c8cbcd;--blu-button-color-text: rgba(25, 34, 42, .2);--blu-button-color-icon: rgba(25, 34, 42, .2)}html:not([dark]) .blu-button.b-secondary.b-disabled[data-v-498b5b0a]:not(.b-inverted){--blu-button-color-background: #e1e3e4;--blu-button-color-border: #c8cbcd;--blu-button-color-text: rgba(25, 34, 42, .2);--blu-button-color-icon: rgba(25, 34, 42, .2)}html:not([dark]) .blu-button.b-tertiary.b-common[data-v-498b5b0a]{--blu-button-color-text: #006dea;--blu-button-color-icon: #0072ff}html:not([dark]) .blu-button.b-tertiary.b-common.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-common[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-common[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-common[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #f3f9ff;--blu-button-color-border: transparent}html:not([dark]) .blu-button.b-tertiary.b-danger[data-v-498b5b0a]{--blu-button-color-text: #d33534;--blu-button-color-icon: #e93c3c}html:not([dark]) .blu-button.b-tertiary.b-danger.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-danger[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-danger[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-danger[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #fff5f5;--blu-button-color-border: transparent}html:not([dark]) .blu-button.b-tertiary.b-inverted[data-v-498b5b0a]{--blu-button-color-text: #ffffff;--blu-button-color-icon: #ffffff}html:not([dark]) .blu-button.b-tertiary.b-inverted.b-hover[data-v-498b5b0a]:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-inverted[data-v-498b5b0a]:hover:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-inverted[data-v-498b5b0a]:active:not(.b-disabled),html:not([dark]) .blu-button.b-tertiary.b-inverted[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: rgba(255, 255, 255, .4);--blu-button-color-border: transparent}html:not([dark]) .blu-button.b-tertiary.b-disabled[data-v-498b5b0a]{--blu-button-color-text: rgba(255, 255, 255, .4);--blu-button-color-icon: rgba(255, 255, 255, .4)}html:not([dark]) .blu-button.b-tertiary.b-disabled[data-v-498b5b0a]:not(.b-inverted){--blu-button-color-text: rgba(25, 34, 42, .2);--blu-button-color-icon: rgba(25, 34, 42, .2)}html:not([dark]) a[data-v-498b5b0a]{text-decoration:none}html[dark] button[data-v-498b5b0a]{border:none;background:none;cursor:pointer;font-family:Blibli,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif}html[dark] input[type=submit][data-v-498b5b0a]::-moz-focus-inner,html[dark] input[type=button][data-v-498b5b0a]::-moz-focus-inner{border:0px}html[dark] button[data-v-498b5b0a]:focus,html[dark] input[type=submit][data-v-498b5b0a]:focus,html[dark] input[type=button][data-v-498b5b0a]:focus,html[dark] input[type=reset][data-v-498b5b0a]:focus,html[dark] a[data-v-498b5b0a]{outline:none}html[dark] .blu-button[data-v-498b5b0a]{--blu-button-border-width: 1px;--blu-button-border-radius: 64px;--blu-button-color-text: #ffffff;--blu-button-color-icon: #ffffff;--blu-button-opacity: $blu-button-opacity;--blu-button-size-height: 48px;--blu-button-icon-size: 24px;--blu-button-spacing-padding: 0 32px;--blu-button-spacing-gap: 8px;--blu-button-text: 600 16px/20px Blibli, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;padding:var(--blu-button-spacing-padding);height:var(--blu-button-size-height);border-radius:var(--blu-button-border-radius);transition:transform .3s .08s,all .3s;color:var(--blu-button-color-text);background-color:var(--blu-button-color-background);font:var(--blu-button-text);box-shadow:0 0 0 var(--blu-button-border-width) var(--blu-button-color-border);display:inline-flex;justify-content:center;align-items:center;white-space:nowrap}html[dark] .blu-button[data-v-498b5b0a]:active:hover:not(.b-disabled),html[dark] .blu-button:active.b-hover[data-v-498b5b0a]:not(.b-disabled){transform:scale(.875)}html[dark] .blu-button[data-v-498b5b0a]:focus-visible{outline:none}html[dark] .blu-button[data-v-498b5b0a]:focus-visible:not(.b-disabled){box-shadow:0 0 0 2px #f9f9fa}html[dark] .blu-button__icon[data-v-498b5b0a]{display:flex;color:var(--blu-button-color-icon)}html[dark] .blu-button__icon[data-v-498b5b0a] svg{width:var(--blu-button-icon-size);height:var(--blu-button-icon-size)}html[dark] .blu-button.b-has-icon:not(.b-has-icon-only) .blu-button__icon[data-v-498b5b0a]{margin-right:var(--blu-button-spacing-gap)}html[dark] .blu-button.b-has-icon-only[data-v-498b5b0a]{--blu-button-spacing-padding: 0 12px}html[dark] .blu-button.b-loading[data-v-498b5b0a] .blu-loader-wrapper svg{display:flex;width:18px;height:18px}html[dark] .blu-button.b-disabled[data-v-498b5b0a]{cursor:not-allowed}html[dark] .blu-button.b-disabled[data-v-498b5b0a]:active{pointer-events:none}html[dark] .blu-button.b-full-width[data-v-498b5b0a]{width:100%}html[dark] .blu-button.b-primary.b-common[data-v-498b5b0a]{--blu-button-color-background: #0072ff}html[dark] .blu-button.b-primary.b-common.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-primary.b-common[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-primary.b-common[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-primary.b-common[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #1d8fff;--blu-button-color-border: transparent}html[dark] .blu-button.b-primary.b-danger[data-v-498b5b0a]{--blu-button-color-background: #e93c3c}html[dark] .blu-button.b-primary.b-danger.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-primary.b-danger[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-primary.b-danger[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-primary.b-danger[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #ff4646;--blu-button-color-border: transparent}html[dark] .blu-button.b-primary.b-inverted[data-v-498b5b0a]{--blu-button-color-background: #12171d;--blu-button-color-text: #4fa4ff;--blu-button-color-icon: #4fa4ff}html[dark] .blu-button.b-primary.b-inverted.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-primary.b-inverted[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-primary.b-inverted[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-primary.b-inverted[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #19222a;--blu-button-color-border: transparent}html[dark] .blu-button.b-primary.b-disabled[data-v-498b5b0a]{--blu-button-color-background: #3b444c;--blu-button-color-text: rgba(255, 255, 255, .3019607843);--blu-button-color-icon: rgba(255, 255, 255, .3019607843)}html[dark] .blu-button.b-primary.b-disabled[data-v-498b5b0a]:not(.b-inverted){--blu-button-color-background: #3b444c;--blu-button-color-text: rgba(255, 255, 255, .3019607843);--blu-button-color-icon: rgba(255, 255, 255, .3019607843)}html[dark] .blu-button.b-small[data-v-498b5b0a]{--blu-button-border-radius: 64px;--blu-button-size-height: 36px;--blu-button-spacing-padding: 0 16px;--blu-button-text: 600 14px/18px Blibli, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;--blu-button-icon-size: 18px;--blu-button-spacing-gap: 4px}html[dark] .blu-button.b-small.b-has-icon-only[data-v-498b5b0a]{--blu-button-spacing-padding: 0 9px}html[dark] .blu-button[data-v-498b5b0a]{width:var(--blu-button-custom-width)}html[dark] .blu-button.b-secondary[data-v-498b5b0a]{--blu-button-color-background: #12171d}html[dark] .blu-button.b-secondary.b-common[data-v-498b5b0a]{--blu-button-color-border: #4fa4ff;--blu-button-color-text: #4fa4ff;--blu-button-color-icon: #4fa4ff}html[dark] .blu-button.b-secondary.b-common.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-secondary.b-common[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-secondary.b-common[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-secondary.b-common[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #002e7a;--blu-button-color-border: #4fa4ff}html[dark] .blu-button.b-secondary.b-danger[data-v-498b5b0a]{--blu-button-color-border: #ff7373;--blu-button-color-text: #ff7373;--blu-button-color-icon: #ff7373}html[dark] .blu-button.b-secondary.b-danger.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-secondary.b-danger[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-secondary.b-danger[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-secondary.b-danger[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #631818;--blu-button-color-border: #ff7373}html[dark] .blu-button.b-secondary.b-inverted[data-v-498b5b0a]{--blu-button-color-background: rgba(255, 255, 255, .3019607843);--blu-button-color-border: #12171d;--blu-button-color-text: #12171d;--blu-button-color-icon: #12171d}html[dark] .blu-button.b-secondary.b-inverted.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-secondary.b-inverted[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-secondary.b-inverted[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-secondary.b-inverted[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: rgba(18, 23, 29, .4);--blu-button-color-border: #12171d}html[dark] .blu-button.b-secondary.b-disabled[data-v-498b5b0a]{--blu-button-color-background: #3b444c;--blu-button-color-border: #60686e;--blu-button-color-text: rgba(255, 255, 255, .3019607843);--blu-button-color-icon: rgba(255, 255, 255, .3019607843)}html[dark] .blu-button.b-secondary.b-disabled[data-v-498b5b0a]:not(.b-inverted){--blu-button-color-background: #3b444c;--blu-button-color-border: #60686e;--blu-button-color-text: rgba(255, 255, 255, .3019607843);--blu-button-color-icon: rgba(255, 255, 255, .3019607843)}html[dark] .blu-button.b-tertiary.b-common[data-v-498b5b0a]{--blu-button-color-text: #4fa4ff;--blu-button-color-icon: #4fa4ff}html[dark] .blu-button.b-tertiary.b-common.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-common[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-common[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-common[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #002e7a;--blu-button-color-border: transparent}html[dark] .blu-button.b-tertiary.b-danger[data-v-498b5b0a]{--blu-button-color-text: #ff7373;--blu-button-color-icon: #ff7373}html[dark] .blu-button.b-tertiary.b-danger.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-danger[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-danger[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-danger[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: #631818;--blu-button-color-border: transparent}html[dark] .blu-button.b-tertiary.b-inverted[data-v-498b5b0a]{--blu-button-color-text: #12171d;--blu-button-color-icon: #12171d}html[dark] .blu-button.b-tertiary.b-inverted.b-hover[data-v-498b5b0a]:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-inverted[data-v-498b5b0a]:hover:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-inverted[data-v-498b5b0a]:active:not(.b-disabled),html[dark] .blu-button.b-tertiary.b-inverted[data-v-498b5b0a]:focus-visible:not(.b-disabled){--blu-button-color-background: rgba(18, 23, 29, .4);--blu-button-color-border: transparent}html[dark] .blu-button.b-tertiary.b-disabled[data-v-498b5b0a]{--blu-button-color-text: rgba(18, 23, 29, .4);--blu-button-color-icon: rgba(18, 23, 29, .4)}html[dark] .blu-button.b-tertiary.b-disabled[data-v-498b5b0a]:not(.b-inverted){--blu-button-color-text: rgba(255, 255, 255, .3019607843);--blu-button-color-icon: rgba(255, 255, 255, .3019607843)}html[dark] a[data-v-498b5b0a]{text-decoration:none}")); document.head.appendChild(elementStyle);} catch(e) {console.error('vite-plugin-css-injected-by-js', e);} })();import { openBlock as o, createElementBlock as i, createElementVNode as e, resolveComponent as f, createBlock as d, resolveDynamicComponent as m, normalizeClass as _, normalizeStyle as g, withCtx as v, createCommentVNode as a, renderSlot as h } from "vue";
const b = {
  props: {
    anchor: Boolean,
    color: {
      type: String,
      default: "common"
    },
    disabled: Boolean,
    size: String,
    width: [String, Number]
  },
  computed: {
    hasIcon() {
      return this.$slots["item-leading"];
    },
    hasEmptyContent() {
      return !this.$slots.default;
    },
    focusIndex() {
      return this.disabled ? -1 : 0;
    },
    componentType() {
      return this.anchor ? "a" : "button";
    },
    buttonDefaultClasses() {
      return {
        [`b-${this.color}`]: this.color,
        "b-disabled": this.disabled,
        "b-has-icon": this.hasIcon,
        [`b-${this.prominence}`]: this.prominence,
        [`b-${this.size}`]: this.size
      };
    },
    buttonStyles() {
      if (!!this.width)
        return {
          "--blu-button-custom-width": this.width.includes("%") ? this.width : this.width + "px"
        };
    }
  }
}, y = {
  name: "BliGeneralLoader",
  props: {
    inverted: Boolean,
    size: {
      type: Number,
      default: 24
    }
  },
  computed: {
    firstStroke() {
      return this.inverted ? "#E0E0E0" : "#F1F1F1";
    },
    secondStroke() {
      return this.inverted ? "#FFFFFF" : "#0095DA";
    }
  }
}, u = (t, n) => {
  const s = t.__vccOpts || t;
  for (const [l, r] of n)
    s[l] = r;
  return s;
}, w = {
  class: "blu-loader-wrapper"
}, k = ["width", "height"], B = {
  x: "9",
  y: "9",
  width: ".01",
  height: ".01",
  overflow: "visible"
}, S = /* @__PURE__ */ e("animateTransform", {
  attributeName: "transform",
  calcMode: "spline",
  dur: "2",
  fill: "freeze",
  keySplines: "0 0 1 1",
  keyTimes: "0;1",
  repeatCount: "indefinite",
  type: "rotate",
  values: "0;720"
}, null, -1), $ = {
  x: "-7",
  y: "-7",
  width: "14",
  height: "14",
  overflow: "visible"
}, C = {
  x: "9.75",
  y: "7",
  width: ".01",
  height: ".01",
  overflow: "visible"
}, z = {
  x: "-4.25",
  y: "-7",
  width: "8.5",
  height: "14",
  overflow: "visible"
}, x = {
  "clip-path": "url(#fg-clipPath)"
}, T = {
  x: "1.5",
  y: "7",
  width: ".01",
  height: ".01",
  overflow: "visible"
}, F = /* @__PURE__ */ e("animateTransform", {
  attributeName: "transform",
  calcMode: "spline",
  dur: "2",
  fill: "freeze",
  keySplines: "0.42 0 0.58 1;0.42 0 0.58 1",
  keyTimes: "0;0.5;1",
  repeatCount: "indefinite",
  type: "rotate",
  values: "0;145;0"
}, null, -1), M = {
  y: "-5.5",
  width: "5.5",
  height: "11",
  overflow: "visible"
}, I = ["stroke"], N = {
  x: "7",
  y: "7",
  width: ".01",
  height: ".01",
  overflow: "visible"
}, E = {
  transform: "rotate(180)"
}, L = /* @__PURE__ */ e("animateTransform", {
  attributeName: "transform",
  calcMode: "spline",
  dur: "2",
  fill: "freeze",
  keySplines: "0 0 1 1",
  keyTimes: "0;1",
  repeatCount: "indefinite",
  type: "rotate",
  values: "180;540"
}, null, -1), P = {
  x: "-7",
  y: "-7",
  width: "14",
  height: "14",
  overflow: "visible"
}, A = {
  x: "9.75",
  y: "7",
  width: ".01",
  height: ".01",
  overflow: "visible"
}, D = {
  x: "-4.25",
  y: "-7",
  width: "8.5",
  height: "14",
  overflow: "visible"
}, G = {
  "clip-path": "url(#fg_2-clipPath)"
}, V = {
  x: "1.5",
  y: "7",
  width: ".01",
  height: ".01",
  overflow: "visible"
}, W = /* @__PURE__ */ e("animateTransform", {
  attributeName: "transform",
  calcMode: "spline",
  dur: "2",
  fill: "freeze",
  keySplines: "0.42 0 0.58 1;0.42 0 0.58 1",
  keyTimes: "0;0.5;1",
  repeatCount: "indefinite",
  type: "rotate",
  values: "0;145;0"
}, null, -1), O = {
  y: "-5.5",
  width: "5.5",
  height: "11",
  overflow: "visible"
}, R = ["stroke"], j = /* @__PURE__ */ e("defs", null, [/* @__PURE__ */ e("clipPath", {
  id: "fg-clipPath"
}, [/* @__PURE__ */ e("path", {
  d: "M1.5 0a7 7 0 110 14 1.5 1.5 0 01-.144-2.993L1.5 11a4 4 0 000-8 1.5 1.5 0 010-3zm0 0"
})]), /* @__PURE__ */ e("clipPath", {
  id: "fg_2-clipPath"
}, [/* @__PURE__ */ e("path", {
  d: "M1.5 0a7 7 0 110 14 1.5 1.5 0 01-.144-2.993L1.5 11a4 4 0 000-8 1.5 1.5 0 010-3zm0 0"
})])], -1);
function q(t, n, s, l, r, c) {
  return o(), i("div", w, [(o(), i("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    preserveAspectRatio: "none",
    viewBox: "0 0 18 18",
    width: t.size,
    height: t.size,
    overflow: "visible"
  }, [(o(), i("svg", B, [e("g", null, [S, (o(), i("svg", $, [e("g", null, [(o(), i("svg", C, [e("g", null, [(o(), i("svg", z, [e("g", x, [(o(), i("svg", T, [e("g", null, [F, (o(), i("svg", M, [e("g", null, [e("path", {
    d: "M0 11A5.5 5.5 0 100 0",
    fill: "#00000000",
    stroke: t.firstStroke,
    "stroke-dasharray": "0",
    "stroke-linecap": "round",
    "stroke-miterlimit": "10",
    "stroke-width": "3"
  }, null, 8, I)])]))])]))])]))])])), (o(), i("svg", N, [e("g", E, [L, (o(), i("svg", P, [e("g", null, [(o(), i("svg", A, [e("g", null, [(o(), i("svg", D, [e("g", G, [(o(), i("svg", V, [e("g", null, [W, (o(), i("svg", O, [e("g", null, [e("path", {
    d: "M0 11A5.5 5.5 0 100 0",
    fill: "#00000000",
    stroke: t.secondStroke,
    "stroke-dasharray": "0",
    "stroke-linecap": "round",
    "stroke-miterlimit": "10",
    "stroke-width": "3"
  }, null, 8, R)])]))])]))])]))])]))])]))])]))])]))])])), j], 8, k))]);
}
const H = /* @__PURE__ */ u(y, [["render", q]]);
var J = function() {
  return Math.random().toString(36).slice(4);
};
const K = {
  props: {
    prominence: {
      type: String,
      default: "primary"
    },
    fullWidth: Boolean,
    loading: Boolean,
    id: {
      type: String,
      default: () => "bli-button-" + J()
    }
  },
  components: {
    BliGeneralLoader: H
  },
  mixins: [b],
  computed: {
    buttonClasses() {
      return {
        "b-full-width": this.fullWidth,
        "b-has-icon-only": this.hasIcon && this.hasEmptyContent,
        "b-loading": this.loading
      };
    }
  }
}, Q = {
  name: "BliButton",
  mixins: [K]
}, U = {
  key: 1,
  class: "blu-button__icon"
};
function X(t, n, s, l, r, c) {
  const p = f("BliGeneralLoader");
  return o(), d(m(t.componentType), {
    type: "button",
    tabindex: t.focusIndex,
    class: _(["blu-button", [t.buttonDefaultClasses, t.buttonClasses]]),
    disabled: t.disabled,
    style: g(t.buttonStyles),
    id: t.id
  }, {
    default: v(() => [
      t.loading ? (o(), d(p, { key: 0 })) : a("", !0),
      t.hasIcon && !t.loading ? (o(), i("span", U, [
        h(t.$slots, "item-leading", {}, void 0, !0)
      ])) : a("", !0),
      t.loading ? a("", !0) : h(t.$slots, "default", { key: 2 }, void 0, !0)
    ]),
    _: 3
  }, 8, ["tabindex", "class", "disabled", "style", "id"]);
}
const Z = /* @__PURE__ */ u(Q, [["render", X], ["__scopeId", "data-v-498b5b0a"]]);
export {
  Z as default
};
//# sourceMappingURL=Button.js.map
